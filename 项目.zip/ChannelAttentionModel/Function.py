import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
from torchvision import datasets, models
import os
import numpy as np
from sklearn.metrics import classification_report

# Function for training the model
def train_model(model, trainloader, testloader,  criterion, optimizer, device,name,  num_epochs=20):
    for epoch in range(num_epochs):
        model.train()
        running_loss = 0.0
        correct = 0
        total = 0

        for inputs, labels in trainloader:
            inputs, labels = inputs.to(device), labels.to(device)

            optimizer.zero_grad()

            # Forward pass
            outputs = model(inputs)
            loss = criterion(outputs, labels)

            # Backward pass and optimization
            loss.backward()
            optimizer.step()

            # Track loss and accuracy
            running_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

        # Print epoch results
        print(f'Epoch [{epoch + 1}/{num_epochs}], Loss: {running_loss / len(trainloader):.4f}, Accuracy: {100 * correct / total:.2f}%')





        print(f"\nEvaluating model: {name}\n")
        model.eval()  # Set the model to evaluation mode
        all_labels = []
        all_predictions = []
        all_scores = []  # 用于保存预测分数

        with torch.no_grad():
            for inputs, labels in testloader:
                inputs, labels = inputs.to(device), labels.to(device)

                outputs = model(inputs)

                all_scores.extend(outputs.cpu().numpy())  # 保存预测分数（假设输出是概率分数或logits）

                _, predicted = torch.max(outputs, 1)

                all_labels.extend(labels.cpu().numpy())
                all_predictions.extend(predicted.cpu().numpy())

        # 使用 sklearn 的 classification_report 来计算评估指标
        report = classification_report(all_labels, all_predictions, target_names=testloader.dataset.classes, digits=4)

        folder_path = 'experiment_result'
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

        # 打印评估结果
        print(report)

        file_path = os.path.join(folder_path, f'{name}.txt')
        with open(file_path, 'a') as file:
            file.write(report)
            file.write('\n\n\n')

        if epoch == 19:
            score_save_path = f'.\\experiment_result\\{name}_predict.npy'
            np.save(score_save_path, np.array(all_scores))

            label_save_path = f'.\\experiment_result\\{name}_label.npy'
            np.save(label_save_path, np.array(all_labels))

            print(f"Prediction scores saved to {score_save_path}")

# Function for evaluating the model
# def evaluate_model(model, testloader, device):
#     model.eval()  # Set the model to evaluation mode
#     correct = 0
#     total = 0
#     with torch.no_grad():
#         for inputs, labels in testloader:
#             inputs, labels = inputs.to(device), labels.to(device)
#
#             outputs = model(inputs)
#             _, predicted = torch.max(outputs, 1)
#             total += labels.size(0)
#             correct += (predicted == labels).sum().item()
#
#     # Print test accuracy
#     print(f'Test Accuracy: {100 * correct / total:.2f}%')




# def evaluate_model(model, testloader, device, model_name="",score_save_path="predictions.phy", report_save_path="evaluation_report.txt"):
#     print(f"\nEvaluating model: {model_name}\n")
#     model.eval()  # Set the model to evaluation mode
#     all_labels = []
#     all_predictions = []
#     all_scores = []  # 用于保存预测分数
#
#     with torch.no_grad():
#         for inputs, labels in testloader:
#             inputs, labels = inputs.to(device), labels.to(device)
#
#             outputs = model(inputs)
#
#             all_scores.extend(outputs.cpu().numpy())# 保存预测分数（假设输出是概率分数或logits）
#
#             _, predicted = torch.max(outputs, 1)
#
#             all_labels.extend(labels.cpu().numpy())
#             all_predictions.extend(predicted.cpu().numpy())
#
#     # 使用 sklearn 的 classification_report 来计算评估指标
#     report = classification_report(all_labels, all_predictions, target_names=testloader.dataset.classes)
#
#     # 打印评估结果
#     print(report)
#
#     with open(report_save_path, 'w') as f:
#         f.write(report)
#
#     print(f"Classification report saved to {report_save_path}")
#
#     # 保存预测分数为 .phy 文件
#     np.save(score_save_path, np.array(all_scores))
#     print(f"Prediction scores saved to {score_save_path}")

"""
使用例子如下：
train_model(model, trainloader, criterion, optimizer, device, num_epochs=20)
evaluate_model(model, testloader, device)
"""