import torch
import torchvision
import torch.optim as optim
import torch.nn as nn
import torchvision.transforms as transforms
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
import numpy as np

class CIFARCNN(nn.Module):
    def __init__(self):
        super(CIFARCNN,self).__init__()
        self.convert = nn.Sequential(
            nn.Conv2d(3,32,kernel_size=3,stride=1,padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(),

            nn.MaxPool2d(kernel_size=2, stride=2),

            nn.Conv2d(32,64,kernel_size=3,stride=1,padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),

            nn.MaxPool2d(kernel_size=2, stride=2),

            nn.Conv2d(64,128,kernel_size=3,stride=1,padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(),

            nn.MaxPool2d(kernel_size=2, stride=2),

            nn.Conv2d(128,256,kernel_size=3,stride=1,padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(),

            nn.MaxPool2d(kernel_size=2, stride=2),

            nn.Conv2d(256,512,kernel_size=3,stride=1,padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(),
        )


        self.fc = nn.Sequential(
            nn.Flatten(),
            nn.Linear(512*2*2,512),
            nn.ReLU(),
            nn.Linear(512,10),
            nn.ReLU(),
        )

    def forward(self,x):
            x = self.convert(x)
            x = self.fc(x)
            return x

def train(model,train_loader,val_loader,optimizer,criterion,epochs = 15):
    train_losses,val_losses = [],[]
    for epoch in range(epochs):
        model.train()
        running_loss = 0.0
        for inputs,labels in train_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs,labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()*inputs.size(0)

        epoch_loss = running_loss/len(train_loader.dataset)
        train_losses.append(epoch_loss)

        model.eval()
        val_running_loss = 0.0
        with torch.no_grad():
            for inputs,labels in val_loader:
                inputs, labels = inputs.to(device), labels.to(device)
                outputs = model(inputs)
                loss = criterion(outputs,labels)
                val_running_loss += loss.item()*inputs.size(0)

            val_loss = val_running_loss/len(val_loader.dataset)
            val_losses.append(val_loss)

            print(f'Epoch{epoch+1}/{epochs},train_loss:{epoch_loss:.4f},Val_loss{val_loss:.4f}')

    return train_losses,val_losses

def test(model,test_loader):
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for inputs,labels in test_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            _,predicted = torch.max(outputs,1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

    accuracy = 100 * correct/total
    print(f'Accuracy:{accuracy:.2f}%')



if __name__ == '__main__':
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    transform = transforms.Compose([transforms.ToTensor(),transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))])

    full_train_dataset = torchvision.datasets.CIFAR10(root='/data',train=True,download=True,transform = transform)
    test_dataset = torchvision.datasets.CIFAR10(root='/data',train=False,download=True,transform = transform)

    indices = np.arange(len(full_train_dataset))

    train_indices,val_indices = train_test_split(indices,test_size=5000,random_state=42)

    train_dataset = torch.utils.data.Subset(full_train_dataset,train_indices)
    val_dataset = torch.utils.data.Subset(full_train_dataset,val_indices)

    train_loader = torch.utils.data.DataLoader(train_dataset,batch_size=64,shuffle=True,num_workers=4)
    val_loader = torch.utils.data.DataLoader(val_dataset,batch_size=64,shuffle=False,num_workers=4)
    test_loader = torch.utils.data.DataLoader(test_dataset,batch_size=64,shuffle=False,num_workers=4)
    cnn = CIFARCNN().to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(cnn.parameters(),lr=0.001)

    train_losses,val_losses = train(cnn,train_loader,val_loader,optimizer,criterion)
    test(cnn,test_loader)

    plt.plot(train_losses,label='train_loss')
    plt.plot(val_losses,label='val_loss')

    plt.xlabel('Epoch')
    plt.ylabel('Loss')

    plt.legend()
    plt.title('Loss Curse')

    plt.show()