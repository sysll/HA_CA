import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import models, transforms, datasets
from torch.optim import lr_scheduler
import os
def Level_vertical_pooling(x):
    L_inf = torch.max(torch.sum(torch.abs(x), dim=3), dim=2).values.unsqueeze(2)
    L1 = torch.max(torch.sum(torch.abs(x), dim=2), dim=2).values.unsqueeze(2)
    feature_cat_vec = torch.cat((L_inf, L1), dim=2).flatten(1)
    return feature_cat_vec


class ChannelAttention(nn.Module):
    def __init__(self, in_planes):
        super(ChannelAttention, self).__init__()
        self.LVP = Level_vertical_pooling
        self.fc1 = nn.Linear(2 * in_planes, 4 * in_planes)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Linear(4 * in_planes, in_planes)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        tmp = x
        x = self.LVP(x)

        x = self.fc1(x)
        x = self.relu1(x)
        x = self.fc2(x).unsqueeze(2).unsqueeze(3)
        x = self.sigmoid(x) * tmp
        return x


# 2. ResNetWithChannelAttention (Using a pre-trained ResNet18)
class ResNetWithChannelAttention(nn.Module):
    def __init__(self, pretrained=False, in_planes=64, ratio=16):
        super(ResNetWithChannelAttention, self).__init__()
        # Load pre-trained ResNet18 model
        self.resnet = models.resnet18(pretrained=pretrained)

        # Add ChannelAttention after the first convolution layer
        self.channel_attention = ChannelAttention(64)
        self.channel_attention1 = ChannelAttention(64)
        self.channel_attention2 = ChannelAttention(128)
        self.channel_attention3 = ChannelAttention(256)
        self.channel_attention4 = ChannelAttention(512)

    def forward(self, x):
        x = self.resnet.conv1(x)
        x = self.resnet.bn1(x)
        x = self.resnet.relu(x)
        x = self.resnet.maxpool(x)
        x = self.channel_attention(x)

        x = self.resnet.layer1(x)
        x = self.channel_attention1(x)

        x = self.resnet.layer2(x)
        x = self.channel_attention2(x)

        x = self.resnet.layer3(x)
        x = self.channel_attention3(x)

        x = self.resnet.layer4(x)
        x = self.channel_attention4(x)

        x = self.resnet.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.resnet.fc(x)

        return x

# 定义数据集路径
data_dir = 'D:\\Users\\ASUS\\Desktop\\良性癌症等检测'

# 数据预处理步骤
transform1 = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])  # 因为只有一个通道，所以只需要一个均值和一个标准差
])

# 构建训练和验证的数据集
image_datasets = {x: datasets.ImageFolder(os.path.join(data_dir, x), transform=transform1)
                  for x in ['train', 'val']}

# 数据加载器
dataloaders = {x: torch.utils.data.DataLoader(image_datasets[x], batch_size=128, shuffle=True)
               for x in ['train', 'val']}
trainloader = dataloaders['train']
testloader = dataloaders['val']

# 加载ResNet18模型并微调
model = ResNetWithChannelAttention()

# 将模型移至GPU（如果可用）
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
model = model.to(device)

# 定义损失函数和优化器
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=1e-4)

# 学习率调度器（余弦退火）
scheduler = lr_scheduler.CosineAnnealingLR(optimizer, T_max=10)

# 训练函数
def train_model(model, criterion, optimizer, scheduler, num_epochs=10):
    best_model_wts = model.state_dict()
    best_acc = 0.0

    for epoch in range(num_epochs):
        print(f'Epoch {epoch+1}/{num_epochs}')
        print('-' * 10)

        # 每个epoch都有训练和验证阶段
        for phase in ['train', 'val']:
            if phase == 'train':
                model.train()  # 设定模型为训练模式
            else:
                model.eval()   # 设定模型为评估模式

            running_loss = 0.0
            running_corrects = 0

            # 遍历数据加载器中的批次
            for inputs, labels in dataloaders[phase]:
                inputs = inputs.to(device)
                labels = labels.to(device)

                # 零梯度
                optimizer.zero_grad()

                # 向前传播
                with torch.set_grad_enabled(phase == 'train'):
                    outputs = model(inputs)
                    _, preds = torch.max(outputs, 1)
                    loss = criterion(outputs, labels)

                    # 向后传播 + 优化（只在训练阶段进行）
                    if phase == 'train':
                        loss.backward()
                        optimizer.step()

                # 统计
                running_loss += loss.item() * inputs.size(0)
                running_corrects += torch.sum(preds == labels.data)

            # 每个epoch的损失和准确率
            epoch_loss = running_loss / len(image_datasets[phase])
            epoch_acc = running_corrects.double() / len(image_datasets[phase])

            print(f'{phase} Loss: {epoch_loss:.4f} Acc: {epoch_acc:.4f}')

            # 进行学习率调度
            if phase == 'train':
                scheduler.step()

            # 保存最好的模型
            if phase == 'val' and epoch_acc > best_acc:
                best_acc = epoch_acc
                best_model_wts = model.state_dict()

        print()

    # 加载最佳模型权重
    model.load_state_dict(best_model_wts)
    return model

# 训练模型
model = train_model(model, criterion, optimizer, scheduler, num_epochs=10)
