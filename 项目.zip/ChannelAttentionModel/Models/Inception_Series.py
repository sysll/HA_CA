import torch
import torch.nn as nn
import torch.nn.functional as F

""" 一般的incepV3"""
# 定义 Inception 模块（简化版）
class InceptionModule(nn.Module):
    def __init__(self, in_channels, out1x1, out3x3, out5x5, pool_proj):
        super(InceptionModule, self).__init__()

        # 1x1 卷积
        self.conv1x1 = nn.Conv2d(in_channels, out1x1, kernel_size=1)

        # 3x3 卷积
        self.conv3x3 = nn.Conv2d(in_channels, out3x3, kernel_size=3, padding=1)

        # 5x5 卷积
        self.conv5x5 = nn.Conv2d(in_channels, out5x5, kernel_size=5, padding=2)

        # 最大池化层 + 1x1 卷积
        self.maxpool = nn.Conv2d(in_channels, pool_proj, kernel_size=1)

    def forward(self, x):
        # 每个分支独立计算
        branch1 = F.relu(self.conv1x1(x))
        branch2 = F.relu(self.conv3x3(x))
        branch3 = F.relu(self.conv5x5(x))
        branch4 = F.relu(self.maxpool(x))

        # 拼接各分支输出
        return torch.cat([branch1, branch2, branch3, branch4], 1)


# 定义 InceptionV3 模型
class InceptionV3(nn.Module):
    def __init__(self, num_classes=1000):
        super(InceptionV3, self).__init__()

        # 第一层卷积
        self.conv1 = nn.Conv2d(3, 32, kernel_size=3, stride=2)
        self.conv2 = nn.Conv2d(32, 32, kernel_size=3)
        self.conv3 = nn.Conv2d(32, 64, kernel_size=3, padding=1)

        # 最大池化
        self.maxpool1 = nn.MaxPool2d(kernel_size=3, stride=2)

        # 第一个 Inception 模块
        self.inception1 = InceptionModule(64, 64, 128, 32, 32)

        # 第二个 Inception 模块
        self.inception2 = InceptionModule(256, 128, 192, 96, 64)

        # 第三个 Inception 模块
        self.inception3 = InceptionModule(480, 192, 256, 128, 128)

        # 平均池化
        self.avgpool = nn.AdaptiveAvgPool2d(1)

        # 全连接层
        self.fc = nn.Linear(704, num_classes)

    def forward(self, x):
        # 逐层计算
        x = F.relu(self.conv1(x))
        x = F.relu(self.conv2(x))
        x = F.relu(self.conv3(x))
        x = self.maxpool1(x)

        x = self.inception1(x)
        x = self.inception2(x)
        x = self.inception3(x)

        # 全局平均池化
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        # 分类
        x = self.fc(x)

        return x

def Get_InceptionV3(num_classes):
    return InceptionV3(num_classes = num_classes)




"""SE_IncepitonV3"""
class ChannelAttention(nn.Module):
    def __init__(self, channel, reduction=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y.expand_as(x)

class SE_InceptionV3(nn.Module):
    def __init__(self, num_classes=1000):
        super(SE_InceptionV3, self).__init__()

        # 第一层卷积
        self.conv1 = nn.Conv2d(3, 32, kernel_size=3, stride=2)
        self.conv2 = nn.Conv2d(32, 32, kernel_size=3)
        self.conv3 = nn.Conv2d(32, 64, kernel_size=3, padding=1)

        # 最大池化
        self.maxpool1 = nn.MaxPool2d(kernel_size=3, stride=2)

        # 第一个 Inception 模块
        self.inception1 = InceptionModule(64, 64, 128, 32, 32)

        # 第二个 Inception 模块
        self.inception2 = InceptionModule(256, 128, 192, 96, 64)

        # 第三个 Inception 模块
        self.inception3 = InceptionModule(480, 192, 256, 128, 128)

        self.channel_attention = ChannelAttention(32)
        self.channel_attention1 = ChannelAttention(64)
        self.channel_attention2 = ChannelAttention(256)
        self.channel_attention3 = ChannelAttention(480)
        self.channel_attention4 = ChannelAttention(704)
        # 平均池化
        self.avgpool = nn.AdaptiveAvgPool2d(1)

        # 全连接层
        self.fc = nn.Linear(704, num_classes)

    def forward(self, x):
        # 逐层计算
        x = F.relu(self.conv1(x))

        x = F.relu(self.conv2(x))

        x = self.channel_attention(x)

        x = F.relu(self.conv3(x))


        x = self.maxpool1(x)

        x = self.channel_attention1(x)


        x = self.inception1(x)

        x = self.channel_attention2(x)

        x = self.inception2(x)

        x = self.channel_attention3(x)

        x = self.inception3(x)

        x = self.channel_attention4(x)

        # 全局平均池化
        x = self.avgpool(x)

        x = torch.flatten(x, 1)

        # 分类
        x = self.fc(x)

        return x

def Get_SE_InceptionV3(num_classes):
    return SE_InceptionV3(num_classes = num_classes)







"""LVPN-Inception"""
def Level_vertical_pooling(x):
    L_inf = torch.max(torch.sum(torch.abs(x), dim=3), dim=2).values.unsqueeze(2)
    L1 = torch.max(torch.sum(torch.abs(x), dim=2), dim=2).values.unsqueeze(2)
    feature_cat_vec = torch.cat((L_inf, L1), dim=2).flatten(1)
    return feature_cat_vec

class LVP_ChannelAttention(nn.Module):
    def __init__(self, in_planes):
        super(LVP_ChannelAttention, self).__init__()
        self.LVP = Level_vertical_pooling
        self.fc1 = nn.Linear(2 * in_planes, int(1.5 * in_planes))
        self.relu1 = nn.Mish()
        self.fc2 = nn.Linear(int(1.5 * in_planes), in_planes)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        tmp = x
        x = self.LVP(x)
        x = self.fc1(x)
        x = self.relu1(x)
        x = self.fc2(x).unsqueeze(2).unsqueeze(3)
        x = self.sigmoid(x) * tmp
        return x


class LVPN_InceptionV3(nn.Module):
    def __init__(self, num_classes=1000):
        super(LVPN_InceptionV3, self).__init__()

        # 第一层卷积
        self.conv1 = nn.Conv2d(3, 32, kernel_size=3, stride=2)
        self.conv2 = nn.Conv2d(32, 32, kernel_size=3)
        self.conv3 = nn.Conv2d(32, 64, kernel_size=3, padding=1)

        self.channel_attention = LVP_ChannelAttention(32)
        self.channel_attention1 = LVP_ChannelAttention(64)
        self.channel_attention2 = LVP_ChannelAttention(256)
        self.channel_attention3 = LVP_ChannelAttention(480)
        self.channel_attention4 = LVP_ChannelAttention(704)

        # 最大池化
        self.maxpool1 = nn.MaxPool2d(kernel_size=3, stride=2)

        # 第一个 Inception 模块
        self.inception1 = InceptionModule(64, 64, 128, 32, 32)

        # 第二个 Inception 模块
        self.inception2 = InceptionModule(256, 128, 192, 96, 64)

        # 第三个 Inception 模块
        self.inception3 = InceptionModule(480, 192, 256, 128, 128)

        # 平均池化
        self.avgpool = nn.AdaptiveAvgPool2d(1)

        # 全连接层
        self.fc = nn.Linear(704, num_classes)

    def forward(self, x):
        # 逐层计算
        x = F.relu(self.conv1(x))

        x = F.relu(self.conv2(x))

        x = self.channel_attention(x)

        x = F.relu(self.conv3(x))

        x = self.maxpool1(x)

        x = self.channel_attention1(x)


        x = self.inception1(x)

        x = self.channel_attention2(x)

        x = self.inception2(x)

        x = self.channel_attention3(x)

        x = self.inception3(x)

        x = self.channel_attention4(x)


        # 全局平均池化
        x = self.avgpool(x)

        x = torch.flatten(x, 1)
        # 分类
        x = self.fc(x)

        return x

def Get_LVPN_InceptionV3(num_classes):
    return LVPN_InceptionV3(num_classes = num_classes)