import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
from torchvision import datasets
import os
from Function import train_model

import random
import numpy as np
def set_seed(seed=42):
    random.seed(seed)  # Python 内置随机数生成器
    np.random.seed(seed)  # NumPy 随机种子
    torch.manual_seed(seed)  # PyTorch CPU 端随机种子
    torch.cuda.manual_seed(seed)  # PyTorch GPU 端随机种子
    torch.cuda.manual_seed_all(seed)  # 多 GPU 训练
    torch.backends.cudnn.deterministic = True  # 确保 CUDA 计算可复现
    torch.backends.cudnn.benchmark = False  # 关闭自动优化，确保一致性

set_seed(42)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

#数据加载
data_dir = 'C:\\Users\\ZSXPC\\Desktop\\data'   # 样本地址
transform1 = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])  # 因为只有一个通道，所以只需要一个均值和一个标准差
])
image_datasets = {x: datasets.ImageFolder(os.path.join(data_dir, x), transform=transform1)
                  for x in ['train', 'val']}
dataloaders = {x: torch.utils.data.DataLoader(image_datasets[x], batch_size=64, shuffle=True)
               for x in ['train', 'val']}
trainloader = dataloaders['train']
testloader = dataloaders['val']


# 消融实验


# Model, Loss Function, and Optimizer

# from Models.ResNet18_Series import Get_LVPN_ResNet18
# model = Get_LVPN_ResNet18(2).to(device)

# from Models.ResNet18_Series import Get_ResNet18
# model = Get_ResNet18(2).to(device)

# from Models.ResNet18_Series import Get_SE_ResNet18
# model = Get_SE_ResNet18(2).to(device)



# from Models.ResNet32_Series import Get_LVPN_ResNet32
# model = Get_LVPN_ResNet32(2).to(device)

# from Models.ResNet32_Series import Get_ResNet32
# model = Get_ResNet32(2).to(device)

# from Models.ResNet32_Series import Get_SE_ResNet32
# model = Get_SE_ResNet32(2).to(device)



# from Models.ResNet50_Series import Get_LVPN_ResNet50
# model = Get_LVPN_ResNet50(2).to(device)

# from Models.ResNet50_Series import Get_ResNet50
# model = Get_ResNet50(2).to(device)

# from Models.ResNet50_Series import Get_SE_ResNet50
# model = Get_SE_ResNet50(2).to(device)



# from Models.Inception_Series import Get_LVPN_InceptionV3
# model = Get_LVPN_InceptionV3(2).to(device)

# from Models.Inception_Series import Get_InceptionV3
# model = Get_InceptionV3(2).to(device)

# from Models.Inception_Series import Get_SE_InceptionV3
# model = Get_SE_InceptionV3(2).to(device)


#对比实验
# from compare_experience.VGG16 import vgg16
# model = vgg16(2).to(device)

# from compare_experience.Densenet import Get_DenseNet
# model = Get_DenseNet(2).to(device)

# from compare_experience.VIT import Get_ViT
# model = Get_ViT(2).to(device)

# from compare_experience.Mobilenet import Get_MobileNet
# model = Get_MobileNet(2).to(device)

# from compare_experience.EffientNet import Get_efficientnet
# model = Get_efficientnet(2).to(device)

# 导入需要的模块
import torch
from Models.ResNet18_Series import Get_LVPN_ResNet18, Get_ResNet18, Get_SE_ResNet18
from Models.ResNet32_Series import Get_LVPN_ResNet32, Get_ResNet32, Get_SE_ResNet32
from Models.ResNet50_Series import Get_LVPN_ResNet50, Get_ResNet50, Get_SE_ResNet50
from Models.Inception_Series import Get_LVPN_InceptionV3, Get_InceptionV3, Get_SE_InceptionV3
from compare_experience.VGG16 import vgg16
from compare_experience.Densenet import Get_DenseNet
from compare_experience.VIT import Get_ViT
from compare_experience.Mobilenet import Get_MobileNet
from compare_experience.EffientNet import Get_efficientnet

# # 假设我们已经设置好device和训练/测试数据加载器
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
#
# # 创建一个模型选择列表
models = [
    (Get_LVPN_ResNet18, 2, 'LVPN_ResNet18'), (Get_ResNet18, 2,'ResNet18'), (Get_SE_ResNet18, 2,'SE_ResNet18'),
    (Get_LVPN_ResNet32, 2,'LVPN_ResNet32'), (Get_ResNet32, 2,'ResNet32'), (Get_SE_ResNet32, 2,'SE_ResNet32'),
    (Get_LVPN_ResNet50, 2,'LVPN_ResNet50'), (Get_ResNet50, 2,'ResNet50'), (Get_SE_ResNet50, 2,'SE_ResNet50'),
    (Get_LVPN_InceptionV3, 2,'LVPN_InceptionV3'), (Get_InceptionV3, 2,'InceptionV3'), (Get_SE_InceptionV3, 2,'SE_InceptionV3'),
    (vgg16, 2,'VGG16'), (Get_DenseNet, 2,'DenseNet'), (Get_ViT, 2,'VIT'), (Get_MobileNet, 2,'MobileNet'), (Get_efficientnet, 2,'EfficientNet')
]

# models = [(Get_MobileNet, 2, 'MobileNet')]
for model_func, num_classes, name in models:
    # 加载模型
    model = model_func(num_classes).to(device)

    # 假设有预定义的loss和optimizer
    criterion = torch.nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters())

    # 训练模
    print(f"Training model: {name}")
    train_model(model, trainloader, testloader, criterion, optimizer, device, name, num_epochs=20)
    print(f"Finished training {name}\n")

#模型















