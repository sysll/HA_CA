import torch
import torchvision
import torch.optim as optim
import numpy as np
import torch.nn as nn
import torchvision.transforms as transforms
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

class CIFARResnet(nn.Module):
    def __init__(self):
        super(CIFARResnet,self).__init__()
        self.convert = nn.Sequential(
            nn.Conv2d(3,64,kernel_size=3,stride=1,padding=1,bias=False),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            self._make_layer(64,128,2,stride=2),
            self._make_layer(128,256,2,stride=2),
            self._make_layer(256,512,2,stride=2),
            nn.AdaptiveAvgPool2d((1,1)),
        )
        self.fc = nn.Linear(512,10)

    def _make_layer(self,in_channels,out_channels,blocks,stride=1):
        layers = []
        layers.append(Block(in_channels,out_channels,stride))
        for _ in range(1,blocks):
            layers.append(Block(out_channels,out_channels))

        return nn.Sequential(*layers)

    def forward(self,x):
        x = self.convert(x)
        x = torch.flatten(x,1)
        x = self.fc(x)
        return x

class Block(nn.Module):
    def __init__(self,in_channels,out_channels,stride=1):
        super(Block,self).__init__()
        self.convert = nn.Sequential(
            nn.Conv2d(in_channels,out_channels,kernel_size=3,stride=stride,padding=1,bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
        )

        self.shortcut = nn.Sequential()
        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_channels,out_channels,kernel_size=1,stride=stride,bias=False),
                nn.BatchNorm2d(out_channels),
            )

    def forward(self,x):
        Restial = x
        x = self.convert(x)
        x += self.shortcut(Restial)
        x = nn.ReLU()(x)

        return x

def train(model,train_loader,val_loader,optimzer,criterion,epochs=15):
    train_losses,val_losses=[],[]
    for epoch in range(epochs):
        model.train()
        running_loss = 0.0
        for inputs,labels in train_loader:
            inputs,labels = inputs.to(device),labels.to(device)
            optimzer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs,labels)
            loss.backward()
            optimzer.step()

            running_loss += loss.item()*inputs.size(0)

        epoch_loss = running_loss/len(train_loader.dataset)
        train_losses.append(epoch_loss)

        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for inputs,labels in val_loader:
                inputs,labels = inputs.to(device),labels.to(device)
                outputs = model(inputs)
                loss = criterion(outputs,labels)
                val_loss += loss.item()*inputs.size(0)

            epoch_val_loss = val_loss/len(val_loader.dataset)
            val_losses.append(epoch_val_loss)
            print(f'Epoch{epoch+1}/{epochs},Train_loss:{epoch_loss:.4f},Val_loss{epoch_val_loss:.4}')
    return train_losses,val_losses

def test(model,test_loader):
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for inputs,labels in test_loader:
            inputs,labels = inputs.to(device),labels.to(device)
            outputs = model(inputs)
            _,predicted = torch.max(outputs,1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

        accuracy = 100*correct/total
        print(f'Accuracy:{accuracy:.2f}%')


if __name__ == '__main__':
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    transform = transforms.Compose([transforms.ToTensor(),transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))])

    full_train_dataset = torchvision.datasets.CIFAR10(root='/data',train=True,download=True,transform=transform)
    test_dataset = torchvision.datasets.CIFAR10(root='/data',train=False,download=True,transform=transform)

    indices = np.arange(len(full_train_dataset))

    train_indices,val_indices = train_test_split(indices,test_size=5000,random_state=42)

    train_dataset = torch.utils.data.Subset(full_train_dataset,train_indices)
    val_dataset = torch.utils.data.Subset(full_train_dataset,val_indices)

    train_loader = torch.utils.data.DataLoader(train_dataset,batch_size = 64,shuffle = True,num_workers = 2)
    val_loader = torch.utils.data.DataLoader(val_dataset,batch_size = 64,shuffle = False,num_workers = 2)
    test_loader = torch.utils.data.DataLoader(test_dataset,batch_size = 64,shuffle = False,num_workers = 2)

    model = CIFARResnet().to(device)
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    criterion = nn.CrossEntropyLoss()

    train_losses,val_losses=train(model,train_loader,val_loader,optimizer,criterion)
    test(model,test_loader)



    plt.plot(train_losses,label = 'Train_losses')
    plt.plot(val_losses,label = 'Val_losses')

    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('CIFARResnet_Loss')
    plt.legend()
    plt.show()










