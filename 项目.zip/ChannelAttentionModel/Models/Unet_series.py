import torch
import torch.nn as nn
import torch.nn.functional as F

class ChannelAttention(nn.Module):
    def __init__(self, in_channels, reduction_ratio=16):
        super(ChannelAttention, self).__init__()
        self.in_channels = in_channels
        self.reduction_ratio = reduction_ratio

        # Squeeze阶段：全局平均池化
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        # Excitation阶段：两层全连接层
        self.fc1 = nn.Conv2d(in_channels, in_channels // reduction_ratio, 1, bias=False)
        self.fc2 = nn.Conv2d(in_channels // reduction_ratio, in_channels, 1, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        # 计算通道注意力
        avg_out = self.avg_pool(x)
        avg_out = self.fc1(avg_out)
        avg_out = F.relu(avg_out)
        avg_out = self.fc2(avg_out)
        avg_out = self.sigmoid(avg_out)

        return x * avg_out  # 将输入特征与注意力权重相乘


import torch.nn.functional as F


class UNetWithCA(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(UNetWithCA, self).__init__()

        # 编码器部分
        self.encoder1 = self.conv_block(in_channels, 64)
        self.encoder2 = self.conv_block(64, 128)
        self.encoder3 = self.conv_block(128, 256)
        self.encoder4 = self.conv_block(256, 512)

        # 解码器部分
        self.decoder4 = self.upconv_block(512, 256)
        self.decoder3 = self.upconv_block(256, 128)
        self.decoder2 = self.upconv_block(128, 64)
        self.decoder1 = self.upconv_block(64, out_channels)

        # 通道注意力
        self.ca1 = ChannelAttention(64)
        self.ca2 = ChannelAttention(128)
        self.ca3 = ChannelAttention(256)
        self.ca4 = ChannelAttention(512)

    def conv_block(self, in_channels, out_channels):
        return nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
            nn.ReLU(inplace=True)
        )

    def upconv_block(self, in_channels, out_channels):
        return nn.Sequential(
            nn.ConvTranspose2d(in_channels, out_channels, kernel_size=2, stride=2),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        # 编码器
        enc1 = self.encoder1(x)  #shape[]
        print(enc1.shape)
        enc1 = self.ca1(enc1)  # 加入通道注意力
        enc2 = self.encoder2(enc1)
        print(enc2.shape)
        enc2 = self.ca2(enc2)
        enc3 = self.encoder3(enc2)
        print(enc3.shape)
        enc3 = self.ca3(enc3)
        print(enc3.shape)
        enc4 = self.encoder4(enc3)
        print(enc4.shape)
        enc4 = self.ca4(enc4)
        print(enc4.shape)

        # 解码器
        dec4 = self.decoder4(enc4)
        print(dec4.shape)

        # 使用F.interpolate调整dec4的尺寸以匹配enc3
        dec4_resized = F.interpolate(dec4, size=enc3.shape[2:], mode='bilinear', align_corners=True)
        print(dec4.shape)

        dec3 = self.decoder3(dec4_resized + enc3)
        print(dec3.shape)
        dec3 = F.interpolate(dec3, size=enc2.shape[2:], mode='bilinear', align_corners=True)
        dec2 = self.decoder2(dec3 + enc2)
        print(dec2.shape)
        dec2 = F.interpolate(dec2, size=enc1.shape[2:], mode='bilinear', align_corners=True)
        dec1 = self.decoder1(dec2 + enc1)
        print(dec1.shape)

        return dec1

import torch

# 假设模型已经定义好了 UNetWithCA 类
model = UNetWithCA(in_channels=1, out_channels=1)

# 生成一个随机输入（批量大小 4，单通道，图像大小 256x256）
x = torch.randn(4, 1, 256, 256)

# 将输入通过模型得到输出
output = model(x)

# 打印输出的尺寸
print("Input shape:", x.shape)
print("Output shape:", output.shape)

