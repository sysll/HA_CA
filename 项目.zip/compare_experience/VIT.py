import torch
import torch.nn as nn
import torchvision.transforms as transforms
from torchvision.models.vision_transformer import VisionTransformer

class ViTClassifier(nn.Module):
    def __init__(self, image_size=224, patch_size=16, num_classes=1000, dim=768, depth=12, heads=12, mlp_dim=3072, dropout=0.1):
        super(ViTClassifier, self).__init__()

        # 定义 Vision Transformer
        self.vit = VisionTransformer(
            image_size=image_size,
            patch_size=patch_size,
            num_layers=depth,
            num_heads=heads,
            hidden_dim=dim,
            mlp_dim=mlp_dim,
            num_classes=num_classes,
            dropout=dropout,
        )

    def forward(self, x):
        return self.vit(x)

# 获取 ViT 模型
def Get_ViT(num_classes):
    return ViTClassifier(num_classes=num_classes)

