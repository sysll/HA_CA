import torch
import torchvision
# torchvison 包含了数据集和处理数据的函数
import torchvision.transforms as transforms
# transforms 将图像数据转换为张量
from sklearn.model_selection import train_test_split
# 分割数据集
import numpy as np

import torch.nn as nn
import torch.optim as optim

class CIFARNet(nn.Module):
    def __init__(self):
        super(CIFARNet,self).__init__()
        self.fc1 = nn.Linear(32*32*3,512)
        self.fc2 = nn.Linear(512,1024)
        self.fc3 = nn.Linear(1024,512)
        self.fc4 = nn.Linear(512,256)
        self.fc5 = nn.Linear(256,128)
        self.fc6 = nn.Linear(128,10)
        self.relu = nn.ReLU()
    def forward(self,x):
        x = x.view(-1,32*32*3)
        x = self.relu(self.fc1(x))
        x = self.relu(self.fc2(x))
        x = self.relu(self.fc3(x))
        x = self.relu(self.fc4(x))
        x = self.relu(self.fc5(x))
        x = self.relu(self.fc6(x))
        return x



import matplotlib.pyplot as plt

def train(model,train_loader,val_loader,optimizer,criterion,epochs = 5):
    train_losses,val_losses = [],[]
    for epoch in range(epochs):
        model.train()
        # 训练模式
        running_loss = 0.0
        # 滚动式记录每批loss
        for inputs,labels in train_loader:
            inputs,labels = inputs.to(device),labels.to(device)
            # 将数据转至gpu处理
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs,labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()*inputs.size(0)
        #     将本批得到的一个损失值（批量梯度下降法）乘以批大小（inputs。size（0）

        epoch_loss = running_loss/len(train_loader.dataset)
        train_losses.append(epoch_loss)

        model.eval()
        val_running_loss = 0.0
        with torch.no_grad():
            for inputs,labels in val_loader:
                inputs, labels = inputs.to(device), labels.to(device)
                outputs = model(inputs)
                loss = criterion(outputs,labels)
                val_running_loss += loss.item()*inputs.size(0)

        val_loss = val_running_loss/len(val_loader.dataset)
        val_losses.append(val_loss)

        print(f'Epoch{epoch+1}/{epochs},Train_loss:{epoch_loss:.4f},Val_loss:{val_loss:.4f}')

    return train_losses,val_losses

def test(model,test_loader):
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for inputs,labels in test_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            _,predicted = torch.max(outputs.data,1)
            # 交叉熵损失函数 得到概率最大的一个类输出
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

    accuracy = 100 * correct / total
    print(f'Accuracy:{accuracy:.2f}%')


if __name__ == '__main__':
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    # 检查使用gpu

    transform = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
    # 数据处理 转为张量 将像素又0-255转为0-1 便于数据处理，归一化处理，像素进行均值为0.5，标准差为0.5处理

    full_train_dataset = torchvision.datasets.CIFAR10(root='/data', train=True, download=True, transform=transform)
    test_dataset = torchvision.datasets.CIFAR10(root='/data', train=False, download=True, transform=transform)


    indices = np.arange(len(full_train_dataset))

    train_indices, val_indices = train_test_split(indices, test_size=5000, random_state=42)

    train_dataset = torch.utils.data.Subset(full_train_dataset, train_indices)
    val_dataset = torch.utils.data.Subset(full_train_dataset, val_indices)

    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=64, shuffle=True, num_workers=2)
    val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=64, shuffle=False, num_workers=2)
    test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=64, shuffle=False, num_workers=2)

    model = CIFARNet().to(device)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)

    train_losses,val_losses=train(model,train_loader,val_loader,optimizer,criterion)

    test(model, test_loader)

    plt.plot(train_losses,label='Train_losses')
    plt.plot(val_losses,label='Val_losses')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.title('Loss Curve')
    plt.show()






