import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
import matplotlib.pyplot as plt

class Generator(nn.Module):
    def __init__(self):
        super(Generator,self).__init__()
        self.model = nn.Sequential(
            nn.Linear(latent_dim, 256),
            nn.ReLU(),
            nn.Linear(256, 512),
            nn.ReLU(),
            nn.Linear(512, 1024),
            nn.ReLU(),
            nn.Linear(1024, 512),
            nn.ReLU(),
            nn.Linear(512, 28 * 28),
            nn.Tanh()
        )

    def forward(self, x):
        x = self.model(x)
        return x.view(-1, 1, 28, 28)

class Discriminator(nn.Module):
    def __init__(self):
        super(Discriminator,self).__init__()
        self.convert = nn.Sequential(
            nn.Conv2d(1,64,kernel_size=4,stride=2,padding=1),
            nn.BatchNorm2d(64),
            nn.LeakyReLU(0.2),
            nn.Conv2d(64,128,kernel_size=4,stride=2,padding=1),
            nn.BatchNorm2d(128),
            nn.LeakyReLU(0.2),
            nn.Flatten(),
            nn.Linear(128 * 7 * 7,1),
            nn.Sigmoid(),
        )


    def forward(self,img):
        return self.convert(img)

def plot_generated_images(generator, num_images=16):
    z = torch.randn(num_images, latent_dim).to(device)  # Generate random noise
    generated_imgs = generator(z).detach()  # Generate images

    plt.figure(figsize=(8, 8))
    for i in range(num_images):
        plt.subplot(4, 4, i + 1)
        plt.imshow(generated_imgs[i].cpu().detach().numpy().squeeze(0), cmap='gray')  # Display image
        plt.axis('off')  # Hide axis
    plt.show()

if __name__ == '__main__':



    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    transform = transforms.Compose([transforms.ToTensor(),transforms.Normalize((0.5,),(0.5))])

    batch_size = 64
    learning_rate = 0.0002
    num_epochs = 100
    latent_dim = 100


    mnist_dataset = torchvision.datasets.MNIST(root='./data',train=True,transform=transform,download=True)
    data_loader = torch.utils.data.DataLoader(dataset = mnist_dataset,batch_size = batch_size,shuffle = True)

    generator = Generator().to(device)
    discriminator = Discriminator().to(device)

    optimizer_g = optim.Adam(generator.parameters(),lr=learning_rate)
    optimizer_d = optim.Adam(discriminator.parameters(),lr=learning_rate)
    criterion = nn.BCELoss()

    for epoch in range(num_epochs):
        for i,(img,_) in enumerate(data_loader):
            imgs = img.to(device)
            real_labels = torch.full((imgs.size(0), 1), 0.9).to(device)
            fake_labels = torch.zeros(imgs.size(0), 1).to(device)

            optimizer_d.zero_grad()
            outputs = discriminator(imgs)
            d_loss_real = criterion(outputs,real_labels)
            d_loss_real.backward()

            z = torch.randn(imgs.size(0), latent_dim).to(device)
            fake_imgs = generator(z)
            # print(fake_imgs.shape)
            outputs = discriminator(fake_imgs.detach())
            d_loss_fake = criterion(outputs,fake_labels)
            d_loss_fake.backward()

            optimizer_d.step()

            optimizer_g.zero_grad()
            outputs = discriminator(fake_imgs)
            g_loss = criterion(outputs,real_labels)
            g_loss.backward()
            optimizer_g.step()

            if (i + 1) % 100 == 0:
                print(f'Epoch [{epoch + 1}/{num_epochs}], d_loss: {d_loss_real.item() + d_loss_fake.item():.4f}, g_loss: {g_loss.item():.4f}')

    plot_generated_images(generator)






