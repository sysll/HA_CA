import torch
import torch.nn as nn
import torch.nn.functional as F

# 定义深度可分离卷积
class DepthwiseSeparableConv(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1):
        super(DepthwiseSeparableConv, self).__init__()
        # 深度卷积
        self.depthwise = nn.Conv2d(in_channels, in_channels, kernel_size=3, stride=stride, padding=1, groups=in_channels, bias=False)
        # 逐点卷积 (1x1卷积)
        self.pointwise = nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=1, bias=False)

    def forward(self, x):
        x = self.depthwise(x)
        x = self.pointwise(x)
        return x


class MobileNet(nn.Module):
    def __init__(self, num_classes=1000):
        super(MobileNet, self).__init__()
        # 定义一个简单的 MobileNet 架构
        self.features = nn.Sequential(
            DepthwiseSeparableConv(3, 32, stride=2),  # 输入通道3 (RGB图像)，输出通道32
            nn.ReLU(inplace=True),
            DepthwiseSeparableConv(32, 64, stride=1),
            nn.ReLU(inplace=True),
            DepthwiseSeparableConv(64, 128, stride=2),
            nn.ReLU(inplace=True),
            DepthwiseSeparableConv(128, 128, stride=1),
            nn.ReLU(inplace=True),
            DepthwiseSeparableConv(128, 256, stride=2),
            nn.ReLU(inplace=True),
            DepthwiseSeparableConv(256, 256, stride=1),
            nn.ReLU(inplace=True),
            DepthwiseSeparableConv(256, 512, stride=2),
            nn.ReLU(inplace=True),
            DepthwiseSeparableConv(512, 512, stride=1),
            nn.ReLU(inplace=True),
            DepthwiseSeparableConv(512, 1024, stride=2),
            nn.ReLU(inplace=True),
        )

        # 添加全连接层
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(1024, num_classes)
        )

    def forward(self, x):
        x = self.features(x)
        x = self.classifier(x)
        return x

def Get_MobileNet(num_classes):
    return MobileNet(num_classes=num_classes)